<?php
session_start();
$pageTitle='Show Items';
include 'init.php';
$itemid = (isset($_GET['itemid']) && is_numeric($_GET['itemid'])) ? intval($_GET['itemid']) : 0;
$stmt = $con->prepare("SELECT items.*,categories.Name AS Cat_Name,users.UserName AS user FROM items
INNER JOIN categories ON categories.ID=items.Cat_ID
INNER JOIN users ON users.UserID=items.User_ID WHERE Item_ID = ? AND Approve=1");
$stmt->execute(array($itemid));
$count=$stmt->rowCount();
if($count>0){
    $item = $stmt->fetch();  
?>
<h1 class='text-center'><?php echo $item['Name']?></h1>
<div class='container'>
    <div class='row'>
        <div class='col-md-3'>
            <?php
       if (!empty($item['Image'])) {
        echo '<img class="image-responsive" src="uploads/items/' . $item['Image'] . '" alt="' . $item['Name'] . ' Image"/>'; // الصورة من قاعدة البيانات
    } else {
        echo '<img class="image-responsive" src="uploads/default.jpg" alt="Default Image"/>'; // صورة افتراضية
    }
                    ?>
        </div>
        <?php function getUserById($userId) {
    global $con; // التأكد من أنك تستخدم الاتصال بقاعدة البيانات
    $stmt = $con->prepare("SELECT * FROM users WHERE UserID = ?");
    $stmt->execute(array($userId));
    return $stmt->fetch();
}
?>
        <div class='col-md-9 item-info'>
            <h2><?php echo $item['Name']?></h2>
            <p><?php echo $item['Description']?></p>
            <ul class='list-unstyled'>
                <li><i class='fa fa-building fa-fw'></i><span>Made In</span>: <?php echo $item['Country_Made']?></li>
                <li><i class='fa fa-tags fa-fw'></i><span>Category</span>:<a href="categories.php?pageid=<?php echo $item['Cat_ID']?>"> <?php echo $item['Cat_Name']?></a></li>
                <?php $addedByUser = getUserById($item['User_ID']); ?>
                <li><i class='fa fa-user fa-fw'></i><span>Added By</span>:<a href="profile.php?userid=<?php echo $addedByUser['UserID']?>"> <?php echo $addedByUser['UserName'] ?> </a></li>
                <li><i class='fa fa-user fa-fw'></i>
                <span>Tags</span>:
                <?php
                $alltags=explode(",",$item['Tags']);
                foreach($alltags as $tag){
                    $tag=str_replace(' ','',$tag);
                    $lowertag=strtolower($tag);
                    if(!empty($tag)){
                        echo "<a href='tags.php?name={$lowertag}'>".$tag."</a> | ";
                    }
                }
                ?>
                </li>
                <li><i class='fa fa-calendar fa-fw'></i><span>Date</span>: <?php echo $item['Add_Date']?></li>
                <li><i class='fa fa-money fa-fw'></i><span>Price</span>: $<?php echo $item['Price']?></li>
            </ul>
        </div>
    </div>
    <hr class='custom-hr'>
    <?php if(isset($_SESSION['user'])){?>
    <div class='row'>
        <div class='col-md-offset-3'>
            <div class='add-comment'>
                <h3>Add Your Comment</h3>
                <form method='POST' action='<?php echo $_SERVER['PHP_SELF'] . '?itemid=' . $item['Item_ID']; ?>'>
                    <textarea name='comment' required></textarea>
                    <input class='btn btn-primary' type='submit' value='Add Comment'/>
                </form>

                <?php 
                if($_SERVER['REQUEST_METHOD']=='POST'){
                    $comment=filter_var($_POST['comment'],FILTER_SANITIZE_STRING);
                    $userid=$item['User_ID'];
                    $itemid=$item['Item_ID'];
                    if(!empty($comment)){
                        $stmt=$con->prepare("INSERT INTO comments(Comment,Status,Comment_Date,Item_ID,User_ID)
                        VALUES (:zcomment,0,Now(),:zitemid,:zuserid)");
                        $stmt->execute(array(
                            'zcomment'=> $comment,
                            'zitemid'=>$itemid,
                            'zuserid'=>$userid
                        ));
                        if($stmt){
                            echo '<div class="alert alert-success">Comment Added Successfully</div>';
                        }
                    }
                }
                ?>
            </div>
        </div>
    </div>
    <?php }else{
        echo '<a href="login.php">Login</a> Or Register To Add Comment';
    }?>
    <hr class='custom-hr'>
    <?php 
            $stmt = $con->prepare("SELECT comments.*,users.UserName AS User_Name FROM comments 
            INNER JOIN users ON users.UserID=comments.User_ID WHERE Item_ID=? AND Status=1 ORDER BY C_ID DESC");
            $stmt->execute(array($item['Item_ID']));
            $comments = $stmt->fetchAll();
            ?>
        <?php 
        $stmt = $con->prepare("SELECT comments.*, users.UserName AS User_Name FROM comments 
            INNER JOIN users ON users.UserID = comments.User_ID WHERE Item_ID = ? AND Status = 1 ORDER BY C_ID DESC");
        $stmt->execute([$item['Item_ID']]);
        $comments = $stmt->fetchAll();
        
        foreach ($comments as $comment) {
            $stmtAvatar = $con->prepare("SELECT Avatar FROM users WHERE UserID = ?");
            $stmtAvatar->execute([$comment['User_ID']]);
            $userAvatar = $stmtAvatar->fetch(PDO::FETCH_ASSOC);
        
            echo "<div class='comment-box'>";
            echo "<div class='row'>";
            echo "<div class='col-sm-2 text-center'>";
            if (!empty($userAvatar['Avatar'])) {
                echo '<img class=" img-thumbnail img-circle center-block" src="uploads/items/' . htmlspecialchars($userAvatar['Avatar']) . '" alt="Avatar Image"/>';
            } else {
                echo '<img class=" img-thumbnail img-circle center-block" src="uploads/default.jpg" alt="Default Image"/>';
            }
            echo htmlspecialchars($comment['User_Name']);
            echo "</div>";
            echo "<div class='col-sm-10'>";
            echo "<p class='lead'>" . htmlspecialchars($comment['Comment']) . "</p>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            echo "<hr class='custom-hr'>";
        }
        ?>
    </div>
</div>
<?php
}else{
    echo 'There Is No Such ID Or This Item Waiting for Approval';
}
include $tpl. 'footer.php';
?>

