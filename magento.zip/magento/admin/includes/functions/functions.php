<?php
function getAll($field,$tableName,$where=NULL,$and=NULL,$orderFiled,$ordering="DESC"){
    global $con;
    $getAll=$con->prepare("SELECT $field FROM $tableName $where $and ORDER BY $orderFiled $ordering");
    $getAll->execute();
    $all=$getAll->fetchAll();
    return $all;
}
function getTitle(){
    global $pageTitle;
    if(isset($pageTitle)){
        echo $pageTitle;
    }else{
        echo'Default';
    }
}
//version one from function
function redirectHome($errorMsg,$seconds=3){
    echo '<div class="alert alert-danger">'.$errorMsg.'</div>';
    echo '<div class="alert alert-info">You Will Be Redirect To Home Page After '. $seconds.' Seconds.</div>';
    header("refresh:$seconds;url=index.php");
    exit();
}
//version two from redirecthome function for any msg
function redirectHome2($Msg,$url=null,$seconds=3){
    if($url===null){
        $url='index.php';
        $link='HomePage';
    }else{
        if(isset($_SERVER['HTTP_REFERER'])&& $_SERVER['HTTP_REFERER']!==' '){
            $url=$_SERVER['HTTP_REFERER'];
            $link='Previous Page';
        }else{
            $url='index.php';
            $link='HomePage';
        }
    }
    echo $Msg;
    echo '<div class="alert alert-info">You Will Be Redirect To '.$link.' After '. $seconds.' Seconds.</div>';
    header("refresh:$seconds;url=$url");
    exit();
}
function checkItem($select,$from,$value){
    global $con;
    $statemant=$con->prepare("SELECT $select FROM $from WHERE $select=?");
    $statemant->execute(array($value));
    $count=$statemant->rowCount();
    return $count;

}
function countItems($item,$table){
    global $con;
    $stmt2=$con->prepare("SELECT COUNT($item)FROM $table");
    $stmt2->execute();
    return $stmt2->fetchColumn();
}
function getLatest($select ,$table ,$order,$limit=5){
    global $con;
    $getStmt=$con->prepare("SELECT $select FROM $table ORDER BY $order DESC LIMIT $limit");
    $getStmt->execute();
    $rows=$getStmt->fetchAll();
    return $rows;
}