<?php
session_start();
$pageTitle='Profile';
include 'init.php';
if (isset($_GET['userid'])) {
    $userId = intval($_GET['userid']);
    $getUser = $con->prepare("SELECT * FROM users WHERE UserID = ?");
    $getUser->execute(array($userId));
    $info = $getUser->fetch();
?>
<h1 class='text-center'>My Profile</h1>
<div class="information block">
    <div class='container'>
        <div class='panel panel-primary'>
            <div class='panel-heading'>
                My Information
            </div>
            <div class='panel-body'>
                <ul class='list-unstyled'>
                    <li><i class='fa fa-unlock-alt fa-fw'></i><span>Login Name:</span> <?php echo $info['UserName']?> </li>
                    <li><i class='fa fa-user fa-fw'></i><span>FullName:</span> <?php echo $info['FullName']?> </li>
                    <li><i class='fa fa-envelope fa-fw'></i><span>Email:</span> <?php echo $info['Email']?> </li>
                    <li><i class='fa fa-calendar fa-fw'></i><span>Registered Date:</span> <?php echo $info['Date']?> </li>
                    <li><i class='fa fa-tags fa-fw'></i><span>Fav Category:</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id='my-ads' class="ads block">
    <div class='container'>
        <div class='panel panel-primary'>
            <div class='panel-heading'>
                My Advertisements
            </div>
            <div class='panel-body'>
                <?php 
                $myItems=getAll("*","items"," where User_ID={$info['UserID']}","","Item_ID");
                if(!empty($myItems)){
                    echo '<div class="row">'; 
                    foreach($myItems as $item){
                        echo '<div class="col-sm-6 col-md-3">';
                            echo '<div class="thumbnail item-box">';
                            if($item['Approve']==0){echo '<span class="approve-status">Waiting Approval</span>';}
                                echo '<span class="price-tag"> $'.$item['Price'].'</span>';
                                if (!empty($item['Image'])) {
                                    echo '<img class="image-responsive" src="uploads/items/' . $item['Image'] . '" alt="' . $item['Name'] . ' Image"/>'; // الصورة من قاعدة البيانات
                                } else {
                                    echo '<img class="image-responsive" src="uploads/default.jpg" alt="Default Image"/>'; // صورة افتراضية
                                } 
                                echo '<div class="caption">';
                                    echo '<h3><a href="items.php?itemid='.$item['Item_ID'].'">'.$item['Name'].'</a></h3>';
                                    echo '<p>'.$item['Description'].'</p>';
                                    echo '<div class="date">'.$item['Add_Date'].'</div>';
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    }
                    echo '</div>'; // أغلق الصف بعد انتهاء جميع الإعلانات
                } else {
                    echo 'There Is No Ads To Show, Create <a href="newAds.php">New Ads</a>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<div class="comments block">
    <div class='container'>
        <div class='panel panel-primary'>
            <div class='panel-heading'>
                My Latest Comments
            </div>
            <div class='panel-body'>
                <?php 
                    $myComments=getAll("Comment","comments","WHERE User_ID={$info['UserID']}","","C_ID");
                    if(!empty($myComments)){
                        foreach($myComments as $comment){
                            echo '<p>'.$comment['Comment'].'</p>';
                        }
                    }else{
                        echo 'There Is No Comments To Show';
                    }
                ?>
            </div>
        </div>
    </div>
</div>
<?php
}else{
    header('Location:login.php');
    exit();
}
include $tpl. 'footer.php';
?>
