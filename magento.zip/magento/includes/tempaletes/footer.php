<div class="footer">

</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="<?php echo $js?>bootstrap.min.js"></script>
<script src="<?php echo $js?>frontend.js"></script>
</body>
</html>
