<?php
session_start();
$pageTitle = 'Comments';

if (isset($_SESSION['Username'])) {
    include 'init.php';

    $do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

    // Manage comments
    if ($do == 'Manage') {
        $stmt = $con->prepare("SELECT comments.*,items.Name As Item_Name ,users.UserName AS User_Name FROM  comments 
        INNER JOIN items ON items.Item_ID=comments.Item_ID
        INNER JOIN users ON users.UserID=comments.User_ID ORDER BY C_ID DESC");
        $stmt->execute();
        $rows = $stmt->fetchAll();
        if(!empty($rows)){
        ?>
        <h1 class='text-center'>Manage Comments</h1>
        <div class='container'>
            <div class='table-responsive'>
                <table class='main-table text-center table table-border'>
                    <tr>
                        <td>ID</td>
                        <td>Comment</td>
                        <td>Item Name</td>
                        <td>User Name</td>
                        <td>Added Date</td>
                        <td>Control</td>
                    </tr>
                    <?php
                    foreach ($rows as $row) {
                        echo '<tr>';
                        echo '<td>' . $row['C_ID'] . '</td>';
                        echo '<td>' . $row['Comment'] . '</td>';
                        echo '<td>' . $row['Item_Name'] . '</td>';
                        echo '<td>' . $row['User_Name'] . '</td>';
                        echo '<td>' . $row['Comment_Date'] . '</td>';
                        echo '<td>
                                <a href="comments.php?do=Edit&c_id=' . $row["C_ID"] . '" class="btn btn-success"><i class=" fa fa-edit "></i>Edit</a>
                                <a href="comments.php?do=Delete&c_id=' . $row["C_ID"] . '" class="btn btn-danger confirm"><i class=" fa fa-close "></i>Delete</a>';
                                if($row['Status']==0){
                                    echo '<a href="comments.php?do=Approve&c_id=' . $row["C_ID"] . '" class="btn btn-info activate"><i class=" fa fa-check "></i>Approve</a>' ; 
                                }
                        echo  '</td>';
                        echo '</tr>';
                    }
                    ?>
                </table>
            </div>
        </div>
        <?php }else{
            echo '<div class="container">';
                echo '<div class="nice-message">There Is No Comment To Manage  </div>';
            echo '</div>';
        } ?>
        <?php
    } elseif ($do == 'Edit') {
        $c_id = (isset($_GET['c_id']) && is_numeric($_GET['c_id'])) ? intval($_GET['c_id']) : 0;
        $stmt = $con->prepare("SELECT * FROM comments WHERE C_ID = ?");
        $stmt->execute(array($c_id));
        $row = $stmt->fetch();
        $count = $stmt->rowCount();
        
        if ($count > 0) { ?>
            <h1 class='text-center'>Edit Comment</h1>
            <div class='container'>
                <form class='form-horizontal' action='?do=Update' method='POST'>
                    <input type='hidden' name='c_id' value='<?php echo $c_id ?>' />
                    <div class='form-group form-group-lg'>
                        <label class='col-sm-2 control-label'>Comment</label>
                        <div class='col-sm-10 col-md-6'>
                            <textarea class='form-control' name='comment'><?php echo $row['Comment']?></textarea>
                        </div>
                    </div>
                    <div class='form-group form-group-lg'>
                        <div class='col-sm-offset-2 col-sm-10'>
                            <input type='submit' value='Save' class='btn btn-primary btn-lg'/>
                        </div>
                    </div>
                </form>
            </div>
        <?php
        } else {
            echo '<div class="container">';
            $Msg='<div class="alert alert-danger">There Is No Such ID</div>';
            redirectHome2($Msg);
            echo '</div>';
        }
    } elseif ($do == 'Update') {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            echo '<h1 class="text-center">Update Comment</h1>';
            echo '<div class="container">';
            $c_id = $_POST['c_id'];
            $comment = $_POST['comment'];

                $stmt = $con->prepare("UPDATE comments SET Comment = ? WHERE C_ID = ?");
                $stmt->execute(array($comment,$c_id));
                $Msg= "<div class='alert alert-success'>" . $stmt->rowCount() . ' Record Updated.</div>';
                redirectHome2($Msg,'back');
        } else {
            $Msg= '<div class ="alert alert-danger ">Sorry You Can Not Browse This Page Directly.</div>';
            redirectHome2($Msg);
        }
        echo '</div>';
    }elseif($do== 'Delete'){
        echo '<h1 class="text-center">Delete Comment</h1>';
        echo '<div class="container">';
        $c_id = (isset($_GET['c_id']) && is_numeric($_GET['c_id'])) ? intval($_GET['c_id']) : 0;
        $check=checkItem('c_id','comments',$c_id);
        if ($check > 0) { 
            $stmt=$con->prepare("DELETE FROM comments WHERE C_ID= :zcomid");
            $stmt->bindParam(":zcomid" ,$c_id);
            $stmt->execute();
            $Msg= "<div class='alert alert-success'>" . $stmt->rowCount() . ' Record Deleted.</div>';
            redirectHome2($Msg,'back');

        }else{
            $Msg= '<div class= "alert alert-danger ">This ID Is Not Exist.</div>';
            redirectHome2($Msg);
        }
        echo '</div>';
    }elseif($do=='Approve'){
        echo '<h1 class="text-center">Approve Comment</h1>';
        echo '<div class="container">';
        $c_id = (isset($_GET['c_id']) && is_numeric($_GET['c_id'])) ? intval($_GET['c_id']) : 0;
        $check=checkItem('c_id','comments',$c_id);
        if ($check > 0) { 
            $stmt=$con->prepare("UPDATE comments SET Status = 1 WHERE C_ID=? ");
            $stmt->execute(array($c_id));
            $Msg= "<div class='alert alert-success'>" . $stmt->rowCount() . ' Record Status Approve.</div>';
            redirectHome2($Msg,'back');

        }else{
            $Msg= '<div class= "alert alert-danger ">This ID Is Not Exist.</div>';
            redirectHome2($Msg);
        }
        echo '</div>';
    }
    include $tpl . 'footer.php';
} else {
    header('Location:index.php');
    exit();
}
