<?php
$do=isset($_GET['do'])?$_GET['do']:'Manage';
if($do=='Manage'){
    echo '<a href="page.php?do=Add">ADD New Category +</a>';
}
elseif($do=='Add'){
    echo'Add page';
}elseif($do=='Insert'){
    echo'Insert page';
}elseif($do=='Delete'){
    echo'Delete page';
}
else{
    echo 'No page';
}