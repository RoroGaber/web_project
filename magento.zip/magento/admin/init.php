<?php
include 'conect.php';
$tpl ='includes/tempaletes/';
$css='layout/css/';
$js='layout/js/';
$func='includes/functions/';
include "includes/languages/english.php";
include $func.'functions.php';
include $tpl.'header.php';
if(!isset($noNavBar)){
    include $tpl.'navbar.php';
}
?>